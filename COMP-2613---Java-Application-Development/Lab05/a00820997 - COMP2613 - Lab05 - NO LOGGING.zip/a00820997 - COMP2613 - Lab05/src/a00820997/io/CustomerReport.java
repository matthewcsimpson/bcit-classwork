/**
 * Project: COMP2613 - 05 - Lab 05
 * File: CustomerReport.java
 * Date: May 21, 2019
 * Time: 11:59:51 p.m.
 *
 * @author Matthew Simpson / A00820997
 */

package a00820997.io;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Formatter;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.core.config.ConfigurationSource;
import org.apache.logging.log4j.core.config.Configurator;

import a00820997.data.Customer;
import a00820997.data.sort.CompareByJoinDate;

/**
 * @author Matthew Simpson / A00820997
 * @date Spring / Summer 2019
 *
 */
public class CustomerReport {

	private static final String LINE = "------------------------------------------------------------------------------------------------------------------------------------------";
	private static final String FORMATTER = "%-4s %-11s %-11s %-25s %-12s %-12s %-15s %-25s %-10s%n";
	private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("MMM dd yyyy");
	
	public static  String LOG4J_CONFIG_FILENAME = "log4j2.xml";
	private static Logger LOG;
	
	static {
		configureLogging();
		LOG = LogManager.getLogger();
	}


	/**
	 * Private constructor to prevent instantiation
	 */
	private CustomerReport() {
	}

	/**
	 * Method to print both print a report to the console and output a report to a file of all customers, sorted by join date.
	 * 
	 * @param customerData
	 *            - an ArrayList<Customer> - the pre-sorted data to be reported.
	 * @throws FileNotFoundException
	 */
	public static void outputReport(final ArrayList<Customer> customerData) throws FileNotFoundException {
		
		final Formatter output = new Formatter("customers.report.txt");
		LOG.info("Opening Formatter" + output.toString());

		if (customerData != null) {
			try {
				LOG.info("Outputting report file header");
				output.format("Customer Report" + "%n");
				output.format(LINE + "%n");
				output.format(FORMATTER, "ID#", "First Name", "Last Name", "Street", "City", "Postal Code", "Phone #", "Email", "Join Date" + "%n");
				output.format(LINE + "%n");
				
				LOG.info("Outputting report file contents:");
				for (Customer index : customerData) {
					output.format(FORMATTER, index.getId(), index.getFirstName(), index.getLastName(), index.getStreetName(), index.getCity(),
							index.getPostalCode(), index.getPhoneNumber(), index.getEmailAddress(), index.getJoinDate().format(DATE_FORMATTER));
					LOG.debug("Customer: " + index.getId() + ", " + index.getFirstName() + " " + index.getLastName());
				}
				System.out.println();

				System.out.println("Customer Report");
				System.out.println(LINE);
				System.out.format(FORMATTER, "ID#", "First Name", "Last Name", "Street", "City", "Postal Code", "Phone #", "Email", "Join Date");
				System.out.println(LINE);
				LOG.info("Outputting report to console");
				for (Customer index : customerData) {
					System.out.format(FORMATTER, index.getId(), index.getFirstName(), index.getLastName(), index.getStreetName(), index.getCity(),
							index.getPostalCode(), index.getPhoneNumber(), index.getEmailAddress(), index.getJoinDate().format(DATE_FORMATTER));
				}

			} finally {
				LOG.info("Closing formatter");
				output.close();

			}
		}
	}

	/**
	 * Method to generate a report of all customers, sorted by join date, to the console.
	 *
	 * @param customerData
	 *            - a Map<Long, Customer> - the data to report.
	 */

	public static void reportCustomerDB(final Map<Long, Customer> customerData) {
		ArrayList<Customer> sortedList = new ArrayList<>();
		sortedList = CompareByJoinDate.sortData(customerData);
		if (customerData != null) {
			System.out.println("Customer Report");
			System.out.println(LINE);
			System.out.format(FORMATTER, "ID#", "First Name", "Last Name", "Street", "City", "Postal Code", "Phone #", "Email", "Join Date");
			System.out.println(LINE);

			for (final Customer index : sortedList) {
				System.out.format(FORMATTER, index.getId(), index.getFirstName(), index.getLastName(), index.getStreetName(), index.getCity(),
						index.getPostalCode(), index.getPhoneNumber(), index.getEmailAddress(), index.getJoinDate().format(DATE_FORMATTER));
			}

		}
	}

	/**
	 * @deprecated please now use reportCustomerDB()
	 * @see reportCustomerDB();
	 *      Method to generate a report of customers in an array to the console.
	 *
	 * @param customerData
	 *            - a Customer[] array
	 */
	@Deprecated
	public static void reportCustomers(final Customer[] customerData) {
		if (customerData != null) {
			// Set up the report header.
			System.out.println("Customer Report");
			System.out.println(LINE);
			System.out.format(FORMATTER, "ID#", "First Name", "Last Name", "Street", "City", "Postal Code", "Phone #", "Email", "Join Date");
			System.out.println(LINE);

			// loop over the array and output the customer data.
			for (final Customer element : customerData) {

				System.out.format(FORMATTER, element.getId(), element.getFirstName(), element.getLastName(), element.getStreetName(),
						element.getCity(), element.getPostalCode(), element.getPhoneNumber(), element.getEmailAddress(),
						element.getJoinDate().format(DATE_FORMATTER));

			}

		}
				
	}

	/**
	 * Logging
	 */
	private static void configureLogging() {
        ConfigurationSource source;
        try {
            source = new ConfigurationSource(new FileInputStream(LOG4J_CONFIG_FILENAME));
            Configurator.initialize(null, source);
        } catch (IOException e) {
            System.out.println(String.format(
              "Can't find the log4j logging configuration file %s.", LOG4J_CONFIG_FILENAME));
        }
    }
}
