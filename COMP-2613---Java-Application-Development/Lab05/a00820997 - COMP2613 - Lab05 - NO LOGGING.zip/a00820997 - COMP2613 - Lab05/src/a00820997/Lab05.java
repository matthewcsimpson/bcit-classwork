/**
 * Project: COMP2613 - 05 - Lab 05
 * File: Lab05.java
 * Date: May 21, 2019
 * Time: 11:19:37 p.m.
 *
 * @author Matthew Simpson / A00820997
 */

package a00820997;

import java.io.File;
//import java.io.FileInputStream;
import java.io.FileNotFoundException;
//import java.io.IOException;
import java.time.Duration;
import java.time.Instant;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

//import org.apache.logging.log4j.LogManager;
//import org.apache.logging.log4j.Logger;
//import org.apache.logging.log4j.core.config.ConfigurationSource;
//import org.apache.logging.log4j.core.config.Configurator;

import a00820997.data.Customer;
import a00820997.data.sort.CompareByJoinDate;
import a00820997.exceptions.ApplicationException;
import a00820997.io.CustomerReader;
import a00820997.io.CustomerReport;

/**
 * @author Matthew Simpson / A00820997
 * @date Spring / Summer 2019
 *
 */
public class Lab05 {

	private  Map<Long, Customer> newCustomerDB;
	static Instant startTime, endTime;

//	public static  String LOG4J_CONFIG_FILENAME = "log4j2.xml";
//	private static Logger LOG;
//	
//	static {
//		configureLogging();
//		LOG = LogManager.getLogger();
//	}

	
	/**
	 * The Lab05 constructor.  Sets up the HashMap.

	 */
	public Lab05() {
		newCustomerDB = new HashMap<Long, Customer>();
	}

	/**
	 * The main method.
	 *
	 * @param args
	 * @throws ApplicationException
	 */
	public static void main(String[] args) throws ApplicationException {

		startTime = Instant.now();
//		LOG.info("Application Start: " + startTime);
		System.out.println(startTime);
		System.out.println();

		new Lab05().run();

		endTime = Instant.now();
//		LOG.info("Application End: " + endTime);
		System.out.println(endTime);
		long nanoseconds = Duration.between(startTime, endTime).toMillis();
//		LOG.info("Duration: " + nanoseconds + " milliseconds");
		System.out.println("Duration: " + nanoseconds + "milliseconds");

	}


	/**
	 * run the CusteomrReader to break the data down into Customer objects and then run CustomerReport to print out the formatted report.
	 *
	 * @throws ApplicationException
	 */

	private void run() throws ApplicationException {


		Scanner input = null;
//		LOG.info("Starting Scanner");
		try {
			input = new Scanner(new File("customers.txt"));
		} catch (FileNotFoundException e) {
//			LOG.error("ERROR: " + e.getMessage());
			System.exit(-1);
		}

		// skip ahead one line past the header data. 
		input.nextLine();
		try {
			while (input.hasNext()) {
				String inputNewRow = input.nextLine();
//				LOG.debug("Input Data: " + inputNewRow);
				Customer tempCustomer = CustomerReader.readFile(inputNewRow);
//				LOG.debug("Adding New Customer to Map: " + tempCustomer.getId() + ", " + tempCustomer.getFirstName() + " " +tempCustomer.getLastName());
				newCustomerDB.put(tempCustomer.getId(), tempCustomer);
			}
		} catch (DateTimeParseException | NullPointerException e) {
//			LOG.error("ERROR: " + e.getMessage());
			throw new ApplicationException(e.getMessage());
		} finally {
//			LOG.debug("Closing Scanner");
			input.close();
		}

		// create the sorted arraylist
		
		ArrayList<Customer> sortedList = new ArrayList<>(newCustomerDB.values());
//		LOG.info("Creating arraylist to sort customer objects by CompareByJoinDate.");
		sortedList.sort(new CompareByJoinDate());
//		LOG.debug("ArrayList now sorted: " + sortedList.toString());

		// print out the report.
		try {
			CustomerReport.outputReport(sortedList);
		} catch ( FileNotFoundException e) {
//			LOG.error("ERROR: " + e.getMessage());
			throw new ApplicationException(e.getMessage());
		}
		System.out.println();

	}
	
//	private static void configureLogging() {
//        ConfigurationSource source;
//        try {
//            source = new ConfigurationSource(new FileInputStream(LOG4J_CONFIG_FILENAME));
//            Configurator.initialize(null, source);
//        } catch (IOException e) {
//            System.out.println(String.format(
//              "Can't find the log4j logging configuration file %s.", LOG4J_CONFIG_FILENAME));
//        }
//    }


}
