/**
 * Project: COMP2613 - 05 - Lab 05
 * File: Validator.java
 * Date: May 21, 2019
 * Time: 11:59:51 p.m.
 *
 * @author Matthew Simpson / A00820997
 */

package a00820997.data.util;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.core.config.ConfigurationSource;
import org.apache.logging.log4j.core.config.Configurator;

/**
 * @author Matthew Simpson / A00820997
 * @date Spring / Summer 2019
 *
 */
public class Validator {

	/**
	 * Private constructor to prevent instantiation
	 */
	
	public static  String LOG4J_CONFIG_FILENAME = "log4j2.xml";
	private static Logger LOG;
	
	static {
		configureLogging();
		LOG = LogManager.getLogger();
	}

	private Validator() {
	}

	/**
	 * Method to check an email address is valid. If the email is valid, return said email. If it is not valid, return "n/a"
	 *
	 * @param checkEmail
	 *            the email address to be checked.
	 */
	public static boolean checkEmail(final String checkEmail) {
		boolean good = false;
		if (!checkEmail.isEmpty() && checkEmail != null && checkEmail.matches("\\w+@+\\w+\\.\\w{2,6}")) {
			good = true;
			LOG.debug("Email " + checkEmail + " is good");
		} else {
			good = false;
			LOG.debug("Email " + checkEmail + " is bad");

		}
		return good;
	}

	/**
	 * @deprecated Please now use checkEmail();
	 * @see checkEmail()
	 *      Method to check an email address is valid. If the email is valid, return said email. If it is not valid, return "n/a"
	 *
	 * @param checkEmail
	 * @return the email address (or not).
	 */
	@Deprecated
	public String checkEmailAddress(final String checkEmail) {

		if (!checkEmail.isEmpty() && checkEmail != null && checkEmail.matches("\\w+@+\\w+\\.\\w{2,6}")) {
			return checkEmail;
		} else {
			return "n/a";
		}

	}
	
	/**
	 * Logging
	 */
	private static void configureLogging() {
        ConfigurationSource source;
        try {
            source = new ConfigurationSource(new FileInputStream(LOG4J_CONFIG_FILENAME));
            Configurator.initialize(null, source);
        } catch (IOException e) {
            System.out.println(String.format(
              "Can't find the log4j logging configuration file %s.", LOG4J_CONFIG_FILENAME));
        }
    }

}
